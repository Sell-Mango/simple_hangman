let words = null;

async function getWords() {
    await fetch('../src/data/words.txt')
    .then(response => {
        if(!response.ok) {
            throw new Error(`resone status: ${response.status}`);
        }
        console.log(response)
        return response.text();
    })
    .then(data => {
        console.log(data);

        words = data.split('\r\n');
    });

    console.log(words);
}

getWords();

